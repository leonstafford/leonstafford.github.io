<?php
/**
 * UnresolvedApiException
 *
 * @package WP2Static
 */

namespace Aws\Exception;

class UnresolvedApiException extends \RuntimeException {}
