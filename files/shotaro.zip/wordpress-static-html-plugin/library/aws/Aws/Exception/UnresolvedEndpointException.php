<?php
/**
 * UnresolvedEndpointException
 *
 * @package WP2Static
 */

namespace Aws\Exception;

class UnresolvedEndpointException extends \RuntimeException {}
