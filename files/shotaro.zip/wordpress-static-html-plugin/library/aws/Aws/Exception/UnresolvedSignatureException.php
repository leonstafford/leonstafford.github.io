<?php
/**
 * UnresolvedSignatureException
 *
 * @package WP2Static
 */

namespace Aws\Exception;

class UnresolvedSignatureException extends \RuntimeException {}
