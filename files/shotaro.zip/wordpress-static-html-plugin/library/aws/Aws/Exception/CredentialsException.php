<?php
/**
 * CredentialsException
 *
 * @package WP2Static
 */

namespace Aws\Exception;

class CredentialsException extends \RuntimeException {}
