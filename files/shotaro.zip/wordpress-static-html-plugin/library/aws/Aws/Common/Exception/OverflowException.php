<?php
/**
 * OverflowException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class OverflowException extends \OverflowException implements AwsExceptionInterface {}
