<?php
/**
 * RuntimeException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class RuntimeException extends \RuntimeException implements AwsExceptionInterface {}
