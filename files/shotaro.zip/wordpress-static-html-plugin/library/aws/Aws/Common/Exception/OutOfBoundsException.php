<?php
/**
 * OutOfBoundsException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class OutOfBoundsException extends \OutOfBoundsException implements AwsExceptionInterface {}
