<?php
/**
 * RequiredExtensionsNotLoadedException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class RequiredExtensionNotLoadedException extends RuntimeException {}
