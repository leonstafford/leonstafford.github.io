<?php
/**
 * BadMethodCallException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class BadMethodCallException extends \BadMethodCallException implements AwsExceptionInterface {}
