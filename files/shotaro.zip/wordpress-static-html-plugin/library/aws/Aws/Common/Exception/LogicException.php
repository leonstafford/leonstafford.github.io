<?php
/**
 * LogicException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class LogicException extends \LogicException implements AwsExceptionInterface {}
