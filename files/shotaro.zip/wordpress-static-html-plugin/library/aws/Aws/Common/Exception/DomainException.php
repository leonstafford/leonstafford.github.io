<?php
/**
 * DomainException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class DomainException extends \DomainException implements AwsExceptionInterface {}
