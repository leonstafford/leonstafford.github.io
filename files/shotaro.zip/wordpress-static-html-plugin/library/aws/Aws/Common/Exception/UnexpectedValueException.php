<?php
/**
 * UnexpectedValueException
 *
 * @package WP2Static
 */

namespace Aws\Common\Exception;
class UnexpectedValueException extends \UnexpectedValueException implements AwsExceptionInterface {}
