<?php
/**
 * FacadeInterface
 *
 * @package WP2Static
 */

namespace Aws\Common\Facade;
interface FacadeInterface
{
    public static function getServiceBuilderKey();
}
