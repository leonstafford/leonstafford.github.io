<?php
/**
 * ParserException
 *
 * @package WP2Static
 */

namespace Aws\Api\Parser\Exception;

class ParserException extends \RuntimeException {}
