<?php
/**
 * TooManyRedirectsException
 *
 * @package WP2Static
 */

namespace GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException {}
