<?php
/**
 * Index placeholder
 *
 * @package WP2Static
 */

	// Silence is golden.
	// Hide file structure from users on unprotected servers.