<?php
/**
 * Exception
 *
 * @package WP2Static
 */

namespace Github\Exception;

use Http\Client\Exception;

interface ExceptionInterface extends Exception
{
}
