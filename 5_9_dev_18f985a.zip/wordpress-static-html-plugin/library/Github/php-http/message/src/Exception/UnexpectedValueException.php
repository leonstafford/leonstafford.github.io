<?php
/**
 * UnexpectedValueException
 *
 * @package WP2Static
 */

namespace Http\Message\Exception;

use Http\Message\Exception;

final class UnexpectedValueException extends \UnexpectedValueException implements Exception
{
}
