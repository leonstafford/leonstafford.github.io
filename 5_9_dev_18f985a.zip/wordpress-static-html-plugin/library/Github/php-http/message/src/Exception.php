<?php
/**
 * Exception
 *
 * @package WP2Static
 */

namespace Http\Message;

/**
 * An interface implemented by all HTTP message related exceptions.
 */
interface Exception
{
}
