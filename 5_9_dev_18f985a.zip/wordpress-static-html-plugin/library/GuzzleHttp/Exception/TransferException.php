<?php
/**
 * TransferException
 *
 * @package WP2Static
 */

namespace GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException {}
